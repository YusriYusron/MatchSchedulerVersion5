package com.example.yusriyusron.matchscheduler.views

import android.support.test.espresso.Espresso.onView
import android.support.test.espresso.Espresso.pressBack
import android.support.test.espresso.assertion.ViewAssertions.matches
import android.support.test.espresso.contrib.RecyclerViewActions
import android.support.test.espresso.matcher.ViewMatchers.*
import android.support.test.rule.ActivityTestRule
import android.support.test.runner.AndroidJUnit4
import android.support.v7.widget.RecyclerView
import com.example.yusriyusron.matchscheduler.R
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import android.support.test.espresso.NoMatchingViewException
import android.support.test.espresso.action.ViewActions.*
import android.support.test.espresso.assertion.ViewAssertions.doesNotExist
import com.example.yusriyusron.matchscheduler.R.id.*
import org.hamcrest.CoreMatchers.allOf
import android.support.test.espresso.Espresso
import org.junit.Before




@RunWith(AndroidJUnit4::class)
class MainActivityTest{
    @Rule
    @JvmField var activityRule = ActivityTestRule(MainActivity::class.java)


    @Test
    fun testRecyclerViewBehaviour(){
        Thread.sleep(2000)
        onView(withId(viewPagerLayout)).check(matches(isDisplayed()))
        onView(withId(viewPagerLayout)).perform(click())
    }

    @Test
    fun testAppBehavior(){
        Thread.sleep(2000)
        onView(withId(viewPagerLayout)).check(matches(isDisplayed()))
        onView(withId(viewPagerLayout)).perform(click())
        onView(withId(add_to_favorite)).perform(click())
        Thread.sleep(2000)
        pressBack()
        onView(withId(R.id.tLayout)).check(matches(isDisplayed()))
        onView(withText("Next Match")).perform(click())
        onView(withId(viewPagerLayout)).perform(click())
        onView(withId(add_to_favorite)).perform(click())
        Thread.sleep(2000)
        pressBack()
        onView(withText("Favorite")).perform(click())
        Thread.sleep(2000)
    }
}