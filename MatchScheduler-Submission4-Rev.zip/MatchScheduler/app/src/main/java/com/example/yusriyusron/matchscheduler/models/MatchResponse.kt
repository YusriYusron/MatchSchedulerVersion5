package com.example.yusriyusron.matchscheduler.models

data class MatchResponse(
    val events: List<Match>
)