package com.example.yusriyusron.matchscheduler.views

import android.support.test.espresso.Espresso.onView
import android.support.test.espresso.Espresso.pressBack
import android.support.test.espresso.assertion.ViewAssertions.matches
import android.support.test.espresso.contrib.RecyclerViewActions
import android.support.test.espresso.matcher.ViewMatchers.*
import android.support.test.rule.ActivityTestRule
import android.support.test.runner.AndroidJUnit4
import android.support.v7.widget.RecyclerView
import com.example.yusriyusron.matchscheduler.R
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import android.support.test.espresso.NoMatchingViewException
import android.support.test.espresso.action.ViewActions.*
import com.example.yusriyusron.matchscheduler.R.id.*


@RunWith(AndroidJUnit4::class)
class MainActivityTest{
    @Rule
    @JvmField var activityRule = ActivityTestRule(MainActivity::class.java)

    @Test
    fun testRecyclerViewBehaviour(){
        try {
            Thread.sleep(2000)
            onView(withId(viewPagerLayout)).check(matches(isDisplayed()))
            onView(withId(viewPagerLayout)).perform(click())
            Thread.sleep(2000)
            onView(withId(list_match)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(3))
            onView(withId(list_match)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(3, click()))
        }catch (e: NoMatchingViewException){

        }
    }

    @Test
    fun testAppBehavior(){
        try {
            Thread.sleep(2000)
            onView(withId(viewPagerLayout)).check(matches(isDisplayed()))
            onView(withId(viewPagerLayout)).perform(click())
            onView(withId(add_to_favorite)).perform(click())
            Thread.sleep(2000)
            pressBack()
            onView(withId(R.id.tLayout)).check(matches(isDisplayed()))
            onView(withText("Favorite")).perform(click())
            Thread.sleep(2000)
        }catch (e: NoMatchingViewException){

        }
    }
}