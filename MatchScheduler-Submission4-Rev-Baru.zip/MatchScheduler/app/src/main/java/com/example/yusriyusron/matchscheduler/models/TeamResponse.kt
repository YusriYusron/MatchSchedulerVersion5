package com.example.yusriyusron.matchscheduler.models

data class TeamResponse (
    val teams : List<Team>
)